from flask_wtf import FlaskForm, RecaptchaField
from wtforms import StringField, SubmitField, PasswordField, EmailField
from wtforms.validators import DataRequired, Email, EqualTo, ValidationError, Length
import re


def specialchar_check(form,field):
    excluded_chars = "*?!'^+%&/()=}][{$#@<>"

    for char in field.data:
        if char in excluded_chars:
            raise ValidationError(f"Special characters: {char} is not allowed.")


# function to check if password in correct format
def password_check(form, field):
    p = re.compile(r'(?=.*\d)(?=.*[A-Z])(?=.*[a-z])(?=.*\W)')
    if not p.match(field.data):
        raise ValidationError("Password in incorrect format")


# function to check if phone in correct format
def phone_check(form, field):
    p = re.compile(r'\d{4}-\d{3}-\d{4}')
    if not p.match(field.data):
        raise ValidationError("Phone in incorrect format")


class RegisterForm(FlaskForm):

    # register form fields and validation
    email = EmailField(validators=[Email()])
    firstname = StringField(validators=[DataRequired(), specialchar_check])
    lastname = StringField(validators=[DataRequired(), specialchar_check])
    phone = StringField(validators=[phone_check])
    password = PasswordField(validators=[Length(min=6, max=12), password_check])
    confirm_password = PasswordField(validators=[EqualTo('password',
                                                          message='Does not match password field')])
    submit = SubmitField()


class LoginForm(FlaskForm):
    # login form fields and validation
    username = StringField(validators=[DataRequired(), Email()])
    password = PasswordField(validators=[DataRequired()])
    submit = SubmitField()
    recaptcha = RecaptchaField()
    pin = StringField(validators=[DataRequired()])


